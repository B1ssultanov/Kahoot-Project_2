package com.example.demo;

public class FillIn extends Question {

    @Override
    public String toString() {
        return getDescription();
    }
}
